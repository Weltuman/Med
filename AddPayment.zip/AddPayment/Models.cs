﻿using AddPayment;
using Microsoft.Identity.Client.NativeInterop;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Job Job { get; set; }
        public int PaymentType { get; set; }
    }
    public class Job
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public abstract class AbstractPayment
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public Employee Employee { get; set; }
        public double Result { get; set; }
        public void CountResult()
        {
            throw new NotImplementedException();
        }
    }
    public class PieceworkPayment : AbstractPayment
    {
        public double Payment { get; set; }
        public int Amount { get; set; }
        public void CountResult()
        {
            Result = Payment * Amount;
        }
    }
    public class PieceworkPremialPayment : AbstractPayment
    {
        public double Payment { get; set; }
        public double Premium { get; set; }
        public int Amount { get; set; }
        public void CountResult()
        {
            Result = Payment * Amount + Premium;
        }
    }
    public class ProgressivePieceworkPayment : AbstractPayment
    {
        public int Amount { get; set; }
        public int AmountBorder { get; set; }
        public double BeforeBorder { get; set; }
        public double AfterBorder { get; set; }
        public void CountResult()
        {
            if (Amount <= AmountBorder) Result = Amount * BeforeBorder;
            else Result = AmountBorder * BeforeBorder + AfterBorder * (Amount - AmountBorder);
        }
    }
    public class PieceworkIndirectPayment : AbstractPayment
    {
        public double Income { get; set; }
        public double Coefficient { get; set; }
        public void CountResult()
        {
            Result = Income * Coefficient;
        }
    }
}
