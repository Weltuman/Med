﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;

namespace AddPayment
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public AppDbContext context { get; set; } = new AppDbContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void continue_Click(object sender, RoutedEventArgs e)
        {
            if (employeename.Text == "")
            {
                MessageBox.Show("Поле пустое!");
                return;
            }
            string n1 = employeename.Text.Split(" ")[0].ToLower();
            string n2 = employeename.Text.Split(" ")[1].ToLower();
            Employee employee = context.Employees.Where(x => x.Name.ToLower().Contains(n1) && x.Name.ToLower().Contains(n2)).FirstOrDefault();
            if (employee == null)
            {
                MessageBox.Show("Сотрудник не найден!");
                return;
            }
            Payment payment = new Payment(employee);
            payment.Show();
            this.Close();
        }
    }
}
