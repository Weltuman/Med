﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1;

namespace AddPayment
{
    /// <summary>
    /// Логика взаимодействия для Payment.xaml
    /// </summary>
    public partial class Payment : Window
    {
        public AppDbContext context { get; set; } = new AppDbContext();
        public Employee employee { get; set; }
        public Payment(Employee e)
        {
            InitializeComponent();
            employee = context.Employees.Include(x => x.Job).Where(x => x.Id == e.Id).FirstOrDefault();
            switch(employee.PaymentType)
            {
                case 1:
                    g1.Visibility = Visibility.Visible; break;
                case 2:
                    g2.Visibility = Visibility.Visible; break;
                case 3:
                    g3.Visibility = Visibility.Visible; break;
                case 4:
                    g4.Visibility = Visibility.Visible; break;
            }
        }

        private void s1_Click(object sender, RoutedEventArgs e)
        {
            PieceworkPayment pieceworkPayment = new PieceworkPayment()
            {
                Employee = employee,
                Date = DateTime.Now,
                Amount = Convert.ToInt32(amount1.Text),
                Payment = Convert.ToInt32(payment1.Text),
                //Result = Convert.ToInt32(amount1.Text) * Convert.ToInt32(payment1.Text)
            };
            pieceworkPayment.CountResult();
            context.PieceworkPayments.Add(pieceworkPayment);
            context.SaveChanges();
        }

        private void s2_Click(object sender, RoutedEventArgs e)
        {
            PieceworkPremialPayment pieceworkPremialPayment = new PieceworkPremialPayment()
            {
                Employee = employee,
                Date = DateTime.Now,
                Premium = Convert.ToInt32(premium2.Text),
                Amount = Convert.ToInt32(amount2.Text),
                Payment = Convert.ToInt32(payment2.Text),
                //Result = Convert.ToInt32(amount2.Text) * Convert.ToInt32(payment2.Text) + Convert.ToInt32(premium2.Text),
            };
            pieceworkPremialPayment.CountResult();
            context.PieceworkPremialPayments.Add(pieceworkPremialPayment);
            context.SaveChanges();
        }

        private void s3_Click(object sender, RoutedEventArgs e)
        {
            ProgressivePieceworkPayment progressivePieceworkPayment = new ProgressivePieceworkPayment()
            {
                Employee = employee,
                Date = DateTime.Now,
                Amount = Convert.ToInt32(amount3.Text),
                AmountBorder = Convert.ToInt32(border3.Text),
                BeforeBorder = Convert.ToInt32(before3.Text),
                AfterBorder = Convert.ToInt32(after3.Text),
                //Result = res,
            };
            progressivePieceworkPayment.CountResult();
            context.ProgressivePieceworkPayments.Add(progressivePieceworkPayment);
            context.SaveChanges();
        }

        private void s4_Click(object sender, RoutedEventArgs e)
        {
            PieceworkIndirectPayment pieceworkIndirectPayment = new PieceworkIndirectPayment()
            {
                Employee = employee,
                Date = DateTime.Now,
                Income = Convert.ToInt32(income4.Text),
                Coefficient = Convert.ToDouble(percent4.Text) / 100,
                //Result = Convert.ToInt32(income4.Text) * (Convert.ToDouble(percent4.Text) / 100),
            };
            pieceworkIndirectPayment.CountResult();
            context.PieceworkIndirectPayments.Add(pieceworkIndirectPayment);
            context.SaveChanges();
        }
    }
}
