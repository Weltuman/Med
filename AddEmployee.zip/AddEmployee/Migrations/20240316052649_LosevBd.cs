﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AddEmployee.Migrations
{
    /// <inheritdoc />
    public partial class LosevBd : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Systems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Nazv = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Systems", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Job = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SysId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Employees_Systems_SysId",
                        column: x => x.SysId,
                        principalTable: "Systems",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "AbstractPayments",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EmployeeId = table.Column<int>(type: "int", nullable: false),
                    Result = table.Column<double>(type: "float", nullable: false),
                    Discriminator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Income = table.Column<double>(type: "float", nullable: true),
                    Coefficient = table.Column<double>(type: "float", nullable: true),
                    Payment = table.Column<double>(type: "float", nullable: true),
                    Amount = table.Column<int>(type: "int", nullable: true),
                    PieceworkPremialPayment_Payment = table.Column<double>(type: "float", nullable: true),
                    Premium = table.Column<double>(type: "float", nullable: true),
                    PieceworkPremialPayment_Amount = table.Column<int>(type: "int", nullable: true),
                    ProgressivePieceworkPayment_Amount = table.Column<double>(type: "float", nullable: true),
                    AmountBorder = table.Column<double>(type: "float", nullable: true),
                    BeforeBorder = table.Column<double>(type: "float", nullable: true),
                    AfterBorder = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AbstractPayments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AbstractPayments_Employees_EmployeeId",
                        column: x => x.EmployeeId,
                        principalTable: "Employees",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AbstractPayments_EmployeeId",
                table: "AbstractPayments",
                column: "EmployeeId");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_SysId",
                table: "Employees",
                column: "SysId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AbstractPayments");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "Systems");
        }
    }
}
