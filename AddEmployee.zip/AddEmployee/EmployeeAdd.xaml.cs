﻿using System.Linq;
using System.Windows;
using WpfApp1;

namespace AddEmployee
{
    public partial class EmployeeAdd : Window
    {
        
        public EmployeeAdd()
        {
            InitializeComponent();
            using (var context = new AppDbContext())
            {
                payment_type.ItemsSource = context.Systems.Select(x => x.Nazv).ToList();
            }
        }
        private void submit_Click(object sender, RoutedEventArgs e)
        {
            var Ima = $"{lastname.Text} {firstname.Text}";
            var Ps = jobname.Text;
            string Cyc = payment_type.IsEnabled.ToString();
            int id_Sys = 0;
            using (var context = new AppDbContext())
            {
                foreach (var item in context.Systems)
                {
                    if (item.Nazv == Cyc)
                    {
                        id_Sys = item.Id;
                    }
                }
                var users = new Employee { Name = Ima, Job = Ps, SysId = id_Sys };

                context.Employees.Add(users);
                context.SaveChanges();
            }
        }


        private void Sver(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Application.Current.MainWindow.WindowState = WindowState.Minimized;
        }

        private void Closes(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void Drag(object sender, System.Windows.Input.MouseButtonEventArgs e) => DragMove();
    }
}
