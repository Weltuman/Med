﻿using Microsoft.EntityFrameworkCore;

namespace WpfApp1
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        public DbSet<Systema> Systems { get; set; }
        public DbSet<AbstractPayment> AbstractPayments { get; set; }
        public DbSet<PieceworkPayment> PieceworkPayments { get; set; }
        public DbSet<PieceworkPremialPayment> PieceworkPremialPayments { get; set; }
        public DbSet<ProgressivePieceworkPayment> ProgressivePieceworkPayments { get; set; }
        public DbSet<PieceworkIndirectPayment> PieceworkIndirectPayments { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LosevBD;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }
        
    }
}
