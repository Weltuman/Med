﻿using System;

namespace WpfApp1
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Job { get; set; }
        public Systema? Sys { get; set; }
        public int? SysId { get; set; }
    }
    public class Systema
    {
        public int Id { get; set; }
        public string Nazv { get; set; }
    }
    public abstract class AbstractPayment
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public Employee Employee { get; set; }
        public double Result { get; set; }
    }
    public class PieceworkPayment : AbstractPayment
    {
        public double Payment { get; set; }
        public int Amount { get; set; }
    }
    public class PieceworkPremialPayment : AbstractPayment
    {
        public double Payment { get; set; }
        public double Premium { get; set; }
        public int Amount { get; set; }
    }
    public class ProgressivePieceworkPayment : AbstractPayment
    {
        public double Amount { get; set; }
        public double AmountBorder { get; set; }
        public double BeforeBorder { get; set; }
        public double AfterBorder { get; set; }
    }
    public class PieceworkIndirectPayment : AbstractPayment
    {
        public double Income { get; set; }
        public double Coefficient { get; set; }
    }
}
