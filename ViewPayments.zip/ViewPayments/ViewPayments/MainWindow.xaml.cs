﻿using System.Windows;
using WpfApp1;

namespace ViewPayments
{
    public partial class MainWindow : Window
    {
        public AppDbContext context { get; set; } = new AppDbContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void continue_Click(object sender, RoutedEventArgs e)
        {
            if (employeename.Text == "")
            {
                MessageBox.Show("Поле пустое!");
                return;
            }
            string n1 = employeename.Text.Split(" ")[0].ToLower();
            string n2 = employeename.Text.Split(" ")[1].ToLower();
            Employee employee = context.Employees.Where(x => x.Name.ToLower().Contains(n1) && x.Name.ToLower().Contains(n2)).FirstOrDefault();
            if (employee == null)
            {
                MessageBox.Show("Сотрудник не найден!");
                return;
            }
            Payments payments = new Payments(employee);
            payments.Show();
            this.Close();
        }
    }
}