﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1;

namespace ViewPayments
{
    public partial class Payments : Window
    {
        public AppDbContext context { get; set; } = new AppDbContext();
        public Employee employee { get; set; }
        public Payments(Employee e)
        {
            InitializeComponent();
            employee = context.Employees.Include(x => x.Job).Where(x => x.Id == e.Id).FirstOrDefault();
            switch(employee.PaymentType)
            {
                case 1:
                    payments.ItemsSource = context.PieceworkPayments.Include(x => x.Employee).Where(x => x.Employee == employee).ToList();
                    break;
                case 2:
                    payments.ItemsSource = context.PieceworkPremialPayments.Include(x => x.Employee).Where(x => x.Employee == employee).ToList();
                    break;
                case 3:
                    payments.ItemsSource = context.ProgressivePieceworkPayments.Include(x => x.Employee).Where(x => x.Employee == employee).ToList();
                    break;
                case 4:
                    payments.ItemsSource = context.PieceworkIndirectPayments.Include(x => x.Employee).Where(x => x.Employee == employee).ToList();
                    break;
            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
