﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        //DbSet<AbstractPayment> AbstractPayment { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<AbstractPayment> AbstractPayments { get; set; }
        public DbSet<PieceworkPayment> PieceworkPayments { get; set; }
        public DbSet<PieceworkPremialPayment> PieceworkPremialPayments { get; set; }
        public DbSet<ProgressivePieceworkPayment> ProgressivePieceworkPayments { get; set; }
        public DbSet<PieceworkIndirectPayment> PieceworkIndirectPayments { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Belov;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
        }
    }
}
